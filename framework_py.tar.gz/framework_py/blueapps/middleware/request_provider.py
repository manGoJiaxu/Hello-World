# -*- coding: utf-8 -*-
from blueapps.utils.request_provider import RequestProvider

__all__ = ["RequestProvider"]
